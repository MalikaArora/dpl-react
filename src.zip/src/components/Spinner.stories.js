
import React from 'react';
import Spinner from "@avrc/spinner";

export default {
    title: 'Spinner',
}

export const Example = () => {
  return <Spinner />;
}