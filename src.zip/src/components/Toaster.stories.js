// import { withToastProvider,useToast  } from "@avrc/toast";
// import React from 'react';

export default {
    title: 'Toast',
}


export const ShowToast =()=> {
    // const toast = useToast();

    // return <button onClick={() => toast.success("Success")}>Success</button>;
    return <div>hi</div>;
}

// export default withToastProvider(App);
// export const App;