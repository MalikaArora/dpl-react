import React from "react";

export default () => <div className="loader" />;
