import React from 'react';
import Form from './Form';

export default{
    title: 'Form'
}
export const App = () => {
  return <Form />;
}

