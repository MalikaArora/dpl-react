import App from './App';
import React from 'react';
import ReactDOM from "react-dom";
import "./InfiniteScroll.css";

export default {
    title: 'Infinite Scroll',    
  }


export const InfiniteScroll = () => {return <App />;}
