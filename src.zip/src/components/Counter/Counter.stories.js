import React from "react";
import Counter from "./Counter";

export default {
    title: 'Counter',    
  }

export const ShowCounter = () => {
  return (
    <div>
      <Counter/>
    </div>
  );
}