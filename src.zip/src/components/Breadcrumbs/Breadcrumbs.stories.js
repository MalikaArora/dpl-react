import React from 'react';
import ShowBreadcrumbs from "./Breadcrumbs.js";

export default {
    title: 'Breadcrumbs',
}

export const Basic = () => <ShowBreadcrumbs></ShowBreadcrumbs>
