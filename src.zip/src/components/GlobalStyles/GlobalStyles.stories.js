import globalStyles from "@avrc/global-styles";

export default {
    title: 'Global Styles'
}

export const GlobalStyles = () => <div style={{ fontFamily: globalStyles.fontFamily, fontSize: globalStyles.fontSize, focusShadow: globalStyles.focusShadow }} > Global Styles </div>;
