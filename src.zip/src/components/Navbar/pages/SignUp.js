import React from 'react';
import '../ShowNavbar.css';

export default function SignUp() {
  return <h1 className='sign-up'>SIGN UP</h1>;
}