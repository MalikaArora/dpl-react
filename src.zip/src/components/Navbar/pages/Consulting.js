import React from 'react';

export default function Consulting() {
  return (
    <>
      <h1 className='consulting'>CONSULTING</h1>
    </>
  );
}