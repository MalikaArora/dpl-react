import React from 'react';
import '../ShowNavbar.css';

export default function Home() {
  return (
    <>
      <h1 className='home'>OPTUM</h1>
    </>
  );
}